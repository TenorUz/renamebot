package ru.ksenomorf.gavnobot;

import net.dv8tion.jda.core.AccountType;
import net.dv8tion.jda.core.JDA;
import net.dv8tion.jda.core.JDABuilder;
import net.dv8tion.jda.core.entities.Message;
import net.dv8tion.jda.core.entities.MessageChannel;
import net.dv8tion.jda.core.entities.User;
import net.dv8tion.jda.core.events.message.MessageReceivedEvent;
import ru.ksenomorf.gavnobot.command.Command;
import ru.ksenomorf.gavnobot.command.CommandManager;
import ru.ksenomorf.gavnobot.command.commands.admin.*;
import ru.ksenomorf.gavnobot.command.commands.mod.TrollAdd;
import ru.ksenomorf.gavnobot.command.commands.mod.removetroll;
import ru.ksenomorf.gavnobot.command.commands.other.Id;
import ru.ksenomorf.gavnobot.listener.MessageListener;
import ru.ksenomorf.gavnobot.listener.NameChangeListener;
import ru.ksenomorf.gavnobot.logging.Logger;

import javax.security.auth.login.LoginException;

public class GavnoBot {
    public static JDA theBot;

    public static Message getMessage() {
        return message;
    }

    public static MessageChannel getChannel() {
        return channel;
    }

    public static User getSender() {
        return sender;
    }

    public static MessageReceivedEvent getEvent() {
        return event;
    }

    public static Message message;
    public static MessageChannel channel;
    public static User sender;
    public static MessageReceivedEvent event;

    public static void main(String[] args){
        Logger.log("Starting " + Values.botName + " v" + Values.botVersion);
        Logger.log("Made by Ksenomorf");
        Logger.log("----------------------------");

        Logger.log("Starting JDA...");
        try {
            theBot = new JDABuilder(AccountType.BOT).setToken(Values.botToken).buildBlocking();
        }catch(InterruptedException | LoginException ex){
            Logger.log("Cannot log in : " + ex);
            System.exit(-1);
        }

        // Listeners
        theBot.addEventListener(new MessageListener());
        theBot.addEventListener(new NameChangeListener());
        Logger.log("JDA - Successfully added listeners!");

        Logger.log("JDA - Successfully logged in!");
        Logger.log("-----------------------------");
        Logger.log("Started registering commands");

        // Commands
        registerCommand(new ShutdownCommand());
        registerCommand(new NameEveryone());
        registerCommand(new NameEveryoneBack());
        registerCommand(new LeaveCommand());
        registerCommand(new TrollAdd());
        registerCommand(new removetroll());
        registerCommand(new Id());
        registerCommand(new RemChannel());

        // Administrators
        addAdmin("295249205730082817"); // /root/ksenomorf#9595

        Logger.log("Successfully registered " + CommandManager.getCommands().size() + " commands.");
        Logger.log("-----------------------------");

    }

    private static void registerCommand(Command c){
        CommandManager.addCommand(c);
        Logger.log("Command added: " + c.getAlias());
    }

    public static boolean isAdmin(String id){
        return Values.botAdmins.contains(id);
    }

    public static void addAdmin(String id){
        Values.botAdmins.add(id);
    }
}
