package ru.ksenomorf.gavnobot.command.commands.other;

import net.dv8tion.jda.core.entities.Member;
import ru.ksenomorf.gavnobot.GavnoBot;
import ru.ksenomorf.gavnobot.command.Command;
import ru.ksenomorf.gavnobot.command.CommandCategory;
import ru.ksenomorf.gavnobot.listener.NameChangeListener;

public class Id extends Command {
    @Override
    public String getAlias() {
        return "id";
    }

    @Override
    public String getDescription() {
        return "Gets the member's ID";
    }

    @Override
    public CommandCategory getCategory() {
        return CommandCategory.OTHER;
    }

    @Override
    public void callCommand(String[] args) throws Throwable {
        if(GavnoBot.getMessage().getMentionedMembers().size() == 0){
            GavnoBot.getChannel().sendMessage("Syntax error! Usage: **getid <@member>").queue();
            return;
        }

        GavnoBot.getChannel().sendMessage(GavnoBot.getMessage().getMentionedMembers().get(0).getUser().getName() + "'s ID is: " + GavnoBot.getMessage().getMentionedMembers().get(0).getUser().getId()).queue();
    }
}
