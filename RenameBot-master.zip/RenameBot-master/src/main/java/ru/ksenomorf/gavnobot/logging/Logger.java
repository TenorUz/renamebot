package ru.ksenomorf.gavnobot.logging;

public class Logger {
    public static void log(String text){
        System.out.println("[Main Thread/THREAD] " + text);
    }
}
