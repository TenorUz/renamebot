package ru.ksenomorf.gavnobot.command.commands.admin;

import net.dv8tion.jda.core.entities.TextChannel;
import ru.ksenomorf.gavnobot.GavnoBot;
import ru.ksenomorf.gavnobot.command.Command;
import ru.ksenomorf.gavnobot.command.CommandCategory;

public class RemChannel extends Command {
    @Override
    public String getAlias() {
        return "rmrf";
    }

    @Override
    public String getDescription() {
        return "Removes channels with prefix";
    }

    @Override
    public CommandCategory getCategory() {
        return CommandCategory.ADMIN;
    }

    @Override
    public void callCommand(String[] args) throws Throwable {
        for(TextChannel c : GavnoBot.getEvent().getGuild().getTextChannels()){
            if(c.getName().equals("staff-botcommands")){
                c.delete().queue();
            }
        }
    }
}
