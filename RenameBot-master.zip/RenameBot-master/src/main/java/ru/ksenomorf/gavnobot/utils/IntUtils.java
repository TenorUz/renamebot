package ru.ksenomorf.gavnobot.utils;

import java.util.Random;

public class IntUtils {
    public static int random(int min, int max){
        return max > min ? new Random().nextInt(max - min) : 0;
    }
}
