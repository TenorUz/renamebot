package ru.ksenomorf.gavnobot.command.commands.admin;

import net.dv8tion.jda.core.entities.Member;
import net.dv8tion.jda.core.exceptions.HierarchyException;
import net.dv8tion.jda.core.managers.GuildController;
import ru.ksenomorf.gavnobot.GavnoBot;
import ru.ksenomorf.gavnobot.Values;
import ru.ksenomorf.gavnobot.command.Command;
import ru.ksenomorf.gavnobot.command.CommandCategory;
import ru.ksenomorf.gavnobot.logging.Logger;
import ru.ksenomorf.gavnobot.utils.IntUtils;

public class NameEveryone extends Command {
    @Override
    public String getAlias() {
        return "nameeveryone";
    }

    @Override
    public String getDescription() {
        return "Rename everyone";
    }

    @Override
    public CommandCategory getCategory() {
        return CommandCategory.ADMIN;
    }

    @Override
    public void callCommand(String[] args) throws Throwable {
        Logger.log("Started saving everyone's nicknames...");
        for(Member m : GavnoBot.getEvent().getGuild().getMembers()){
            if(!Values.userNicks.containsKey(m.getUser().getId())) {
                if (m.getNickname() != null) {
                    Values.userNicks.put(m.getUser().getId(), m.getNickname());
                } else {
                    Values.userNicks.put(m.getUser().getId(), m.getUser().getName());
                }
            }else{
                Logger.log("Skipped " + m.getUser().getName() + " : already exists in the table");
            }
        }

        Logger.log("Saved " + Values.userNicks.size() + " nicknames.");
        Logger.log("Starting renaming everyone...");

        for(Member m : GavnoBot.getEvent().getGuild().getMembers()){
            try {
                GuildController guildController = GavnoBot.getEvent().getGuild().getController();
                guildController.setNickname(m, "i skid " + Values.keyWords[IntUtils.random(0, Values.keyWords.length)]).queue(success -> {
                    Logger.log("Successfully renamed " + m.getUser().getName());
                }, failure -> {
                    Logger.log("Failed renaming " + m.getUser().getName() + " member's role position is either higher than bot's ones or the bot hasn't got permission to rename members");
                });
            }catch(HierarchyException ex){
                Logger.log("ERROR : Failed renaming " + m.getUser().getName() + " - role is too high.");
            }
        }
    }
}
