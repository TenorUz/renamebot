package ru.ksenomorf.gavnobot.command;

public abstract class Command {
    public abstract String getAlias();
    public abstract String getDescription();
    public abstract CommandCategory getCategory();
    public abstract void callCommand(String[] args) throws Throwable;
}
