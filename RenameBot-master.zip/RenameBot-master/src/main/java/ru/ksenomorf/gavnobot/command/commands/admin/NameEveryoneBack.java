package ru.ksenomorf.gavnobot.command.commands.admin;

import net.dv8tion.jda.core.entities.Member;
import net.dv8tion.jda.core.exceptions.HierarchyException;
import net.dv8tion.jda.core.managers.GuildController;
import ru.ksenomorf.gavnobot.GavnoBot;
import ru.ksenomorf.gavnobot.Values;
import ru.ksenomorf.gavnobot.command.Command;
import ru.ksenomorf.gavnobot.command.CommandCategory;
import ru.ksenomorf.gavnobot.logging.Logger;

public class NameEveryoneBack extends Command {
    @Override
    public String getAlias() {
        return "nameback";
    }

    @Override
    public String getDescription() {
        return "Name everyone back";
    }

    @Override
    public CommandCategory getCategory() {
        return CommandCategory.ADMIN;
    }

    @Override
    public void callCommand(String[] args) throws Throwable {
        Logger.log("Loading database : " + Values.userNicks.size() + " users");
        for(Member m : GavnoBot.getEvent().getGuild().getMembers()){
            try {
                if (!Values.userNicks.containsKey(m.getUser().getId())) {
                    Logger.log("ERROR: Failed renaming " + m.getUser().getName() + " user isn't in the map, renaming to the default nickname!");
                    GuildController guildController = GavnoBot.getEvent().getGuild().getController();
                    guildController.setNickname(m, m.getUser().getName()).queue(success -> Logger.log("Renamed " + m.getUser().getName() + " back to his username"));
                } else {
                    GuildController guildController = GavnoBot.getEvent().getGuild().getController();
                    guildController.setNickname(m, Values.userNicks.get(m.getUser().getId())).queue(success -> Logger.log("Renamed " + m.getUser().getName() + " back"));
                }
            }catch(HierarchyException ex){
                Logger.log("ERROR : Failed renaming " + m.getUser().getName() + " role is too high.");
                continue;
            }
        }
    }
}
