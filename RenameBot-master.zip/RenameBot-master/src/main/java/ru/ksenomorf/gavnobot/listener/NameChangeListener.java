package ru.ksenomorf.gavnobot.listener;

import net.dv8tion.jda.core.events.guild.member.GuildMemberNickChangeEvent;
import net.dv8tion.jda.core.hooks.ListenerAdapter;
import net.dv8tion.jda.core.managers.GuildController;
import ru.ksenomorf.gavnobot.logging.Logger;

import java.util.ArrayList;
import java.util.List;

public class NameChangeListener extends ListenerAdapter {
    public static List<String> trolledPeople = new ArrayList<>();

    public void onGuildMemberNickChange(GuildMemberNickChangeEvent ex){
        if(trolledPeople.contains(ex.getUser().getId())){
            ex.getGuild().getController().setNickname(ex.getMember(), "Incompetent Skid").queue(success -> Logger.log("trolled"));
        }
    }
}
