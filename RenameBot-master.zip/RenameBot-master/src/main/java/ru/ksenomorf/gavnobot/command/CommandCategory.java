package ru.ksenomorf.gavnobot.command;

public enum CommandCategory {
    ADMIN, MOD, FUN, USEFUL, OTHER
}
