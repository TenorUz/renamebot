package ru.ksenomorf.gavnobot.command.commands.mod;

import net.dv8tion.jda.core.entities.Member;
import ru.ksenomorf.gavnobot.GavnoBot;
import ru.ksenomorf.gavnobot.command.Command;
import ru.ksenomorf.gavnobot.command.CommandCategory;
import ru.ksenomorf.gavnobot.listener.NameChangeListener;

public class removetroll extends Command {
    @Override
    public String getAlias() {
        return "remtroll";
    }

    @Override
    public String getDescription() {
        return "Removes a member to the troll-list";
    }

    @Override
    public CommandCategory getCategory() {
        return CommandCategory.MOD;
    }

    @Override
    public void callCommand(String[] args) throws Throwable {
        if(GavnoBot.getMessage().getMentionedMembers().size() == 0){
            GavnoBot.getChannel().sendMessage("Syntax error! Usage: **remtroll <@member1> [@member2] ...").queue();
            return;
        }

        if(GavnoBot.getMessage().getMentionedMembers().size() >= 2){
            for(Member m : GavnoBot.getMessage().getMentionedMembers()){
                NameChangeListener.trolledPeople.add(m.getUser().getId());
            }
            GavnoBot.getChannel().sendMessage("Removed " + GavnoBot.getMessage().getMentionedMembers().size() + " members from the rename-list").queue();

        }else{
            NameChangeListener.trolledPeople.remove(GavnoBot.getMessage().getMentionedMembers().get(0).getUser().getId());
            GavnoBot.getChannel().sendMessage("Removed " + GavnoBot.getMessage().getMentionedMembers().get(0).getUser().getName() + " from the rename-list").queue();
        }
    }
}
