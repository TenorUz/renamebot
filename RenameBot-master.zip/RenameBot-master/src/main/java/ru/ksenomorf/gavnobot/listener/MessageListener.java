package ru.ksenomorf.gavnobot.listener;

import net.dv8tion.jda.core.events.message.MessageReceivedEvent;
import net.dv8tion.jda.core.hooks.ListenerAdapter;
import ru.ksenomorf.gavnobot.GavnoBot;
import ru.ksenomorf.gavnobot.command.CommandManager;
import ru.ksenomorf.gavnobot.logging.Logger;
import ru.ksenomorf.gavnobot.utils.StringUtils;

public class MessageListener extends ListenerAdapter {
    public static String botPrefix = "**";

    public void onMessageReceived(MessageReceivedEvent e){
        GavnoBot.message = e.getMessage();
        GavnoBot.channel = e.getChannel();
        GavnoBot.sender = e.getAuthor();
        GavnoBot.event = e;

        if(GavnoBot.getSender().isBot()) return;
        try {
            if (StringUtils.getCharacters(GavnoBot.getMessage().getContentRaw(), botPrefix.length()).equals(botPrefix)) {
                CommandManager.onCommand(GavnoBot.getMessage().getContentRaw().substring(botPrefix.length()));
            }
        }catch(NullPointerException npe){
            // ignore
        }
    }
}
