package ru.ksenomorf.gavnobot.command;

import net.dv8tion.jda.core.EmbedBuilder;
import net.dv8tion.jda.core.Permission;
import ru.ksenomorf.gavnobot.GavnoBot;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class CommandManager {
    private static List<Command> commands = new ArrayList<>();
    public static void addCommand(Command command) { commands.add(command); }
    public static List<Command> getCommands() { return commands; }

    public static void onCommand(String message){
        String[] argsRaw = message.split(" ");
        String commandCalled = argsRaw[0];
        String[] args = message.substring(commandCalled.length()).split(" "); // I hope it works

        for(Command c : getCommands()){
            if(c.getAlias().equalsIgnoreCase(commandCalled)){
                try {
                    if(GavnoBot.getEvent().getGuild() != null && !GavnoBot.getEvent().getMember().hasPermission(Permission.MANAGE_SERVER) && c.getCategory() == CommandCategory.MOD){
                        GavnoBot.getChannel().sendMessage(new EmbedBuilder().setDescription("You don't have enough permissions to execute this command").setColor(Color.RED).build()).queue();
                        return;
                    }else if(!GavnoBot.isAdmin(GavnoBot.getSender().getId()) && c.getCategory() == CommandCategory.ADMIN){
                        GavnoBot.getChannel().sendMessage(new EmbedBuilder().setDescription("You don't have enough permissions to execute this command").setColor(Color.RED).build()).queue();
                        return;
                    }
                    c.callCommand(args);
                }catch(Throwable t){
                    GavnoBot.getChannel().sendMessage("**An error has occurred!** Check console log for details").queue();
                    t.printStackTrace();
                }
            }
        }
    }
}