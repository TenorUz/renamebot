package ru.ksenomorf.gavnobot.utils;

public class StringUtils {
    public static String getCharacters(String inputString, int limit){
        if(inputString.length() <= limit) return null;
        return inputString.substring(0, Math.min(inputString.length(), limit));
    }
}
