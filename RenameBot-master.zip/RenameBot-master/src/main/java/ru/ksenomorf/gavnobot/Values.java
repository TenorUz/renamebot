package ru.ksenomorf.gavnobot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Values {
    public static String botToken = "oh hello there";
    public static String botName = "GavnoBot";
    public static String botVersion = "0.1a";

    public static List<String> botAdmins = new ArrayList<>();
    public static Map<String, String> userNicks = new HashMap<>();
    public static String[] keyWords = {"killaura", "sprint", "fullbright", "speed", "fly"};
}
