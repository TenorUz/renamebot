package ru.ksenomorf.gavnobot.command.commands.admin;

import net.dv8tion.jda.core.EmbedBuilder;
import ru.ksenomorf.gavnobot.GavnoBot;
import ru.ksenomorf.gavnobot.command.Command;
import ru.ksenomorf.gavnobot.command.CommandCategory;

import java.awt.*;

public class ShutdownCommand extends Command {
    @Override
    public String getAlias() {
        return "shutdown";
    }

    @Override
    public String getDescription() {
        return "Shutdowns the bot";
    }

    @Override
    public CommandCategory getCategory() {
        return CommandCategory.ADMIN;
    }

    @Override
    public void callCommand(String[] args) throws Throwable {
        GavnoBot.getChannel().sendMessage(new EmbedBuilder().setDescription("Shutting down...").setColor(Color.RED).build()).queue(success -> {
            GavnoBot.theBot.shutdownNow();
        });
    }
}
