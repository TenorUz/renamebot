package ru.ksenomorf.gavnobot.command.commands.admin;

import ru.ksenomorf.gavnobot.GavnoBot;
import ru.ksenomorf.gavnobot.command.Command;
import ru.ksenomorf.gavnobot.command.CommandCategory;

public class LeaveCommand extends Command {
    @Override
    public String getAlias() {
        return "leave";
    }

    @Override
    public String getDescription() {
        return "Leave the server";
    }

    @Override
    public CommandCategory getCategory() {
        return CommandCategory.ADMIN;
    }

    @Override
    public void callCommand(String[] args) throws Throwable {
        GavnoBot.getChannel().sendMessage("Меня послали нахуй. Пока, пидорки, я вас ненавидел.").queue(success -> GavnoBot.getEvent().getGuild().leave().queue());
    }
}
